import FWCore.ParameterSet.Config as cms

pythia8CUEP8S1herapdfSettingsBlock = cms.PSet(
    pythia8CUEP8S1herapdfSettings = cms.vstring(
        'Tune:pp 16',
        'Tune:ee 3',      
   )
)

