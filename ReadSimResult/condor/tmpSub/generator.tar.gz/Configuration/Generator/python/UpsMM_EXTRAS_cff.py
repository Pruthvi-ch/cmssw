
from Configuration.Generator.UpsMM_cfi import *
from Configuration.Generator.UpsMM_filt_cfi import *

ProductionFilterSequence = cms.Sequence(mumugenfilter)
